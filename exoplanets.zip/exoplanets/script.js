
}

// Search functionality
searchInput.addEventListener('input', () => {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredPlanets = exoplanets.filter(planet => planet.name.toLowerCase().includes(searchTerm));
    displayExoplanets(filteredPlanets);
});

// Data visualization function
function drawChart() {
    const ctx = document.getElementById('chart-container').getContext('2d');
    const labels = exoplanets.map(p => p.name);
    const data = {
        labels: labels,
        datasets: [{
            label: 'Exoplanet Details',
            data: labels.map(() => Math.random() * 100), // Replace with actual data
            backgroundColor: 'rgba(74, 144, 226, 0.2)',
            borderColor: 'rgba(74, 144, 226, 1)',
            borderWidth: 1
        }]
    };
    new Chart(ctx, {
        type: 'bar',
        data: data,
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

// Roulette functionality
document.getElementById('spin-roulette').addEventListener('click', () => {
    const randomPlanet = exoplanets[Math.floor(Math.random() * exoplanets.length)];
    rouletteResult.innerHTML = `<h3>You landed on: ${randomPlanet.name}</h3><p>${randomPlanet.details}</p>`;
    rouletteSection.style.display = 'block';
});

// Initial display
displayExoplanets(exoplanets);
drawChart(); // Call to draw the chart

